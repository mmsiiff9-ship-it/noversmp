package com.novar.smp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.*;
import java.util.*;

public final class NovaSMP extends JavaPlugin implements Listener {
    private Connection db;
    private final Map<UUID, Double> cache = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            File dbFile = new File(getDataFolder(), "economy.db");
            getDataFolder().mkdirs();
            db = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement st = db.createStatement()) {
                st.executeUpdate("CREATE TABLE IF NOT EXISTS balances (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, balance REAL NOT NULL)");
            }
        } catch (SQLException ex) {
            getLogger().severe("Could not open economy database: " + ex.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("NovaSMP enabled.");
    }

    @Override
    public void onDisable() {
        if (db != null) try { db.close(); } catch (SQLException ignored) {}
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private String prefix() { return color("&8[&aNOVAR&8] &7"); }
    private String moneyText(double amount) {
        return String.format(Locale.US, "%,.2f", amount) + getConfig().getString("currency-symbol", "$");
    }

    private double balance(OfflinePlayer p) {
        if (cache.containsKey(p.getUniqueId())) return cache.get(p.getUniqueId());
        double value = getConfig().getDouble("starting-balance", 10000.0);
        try (PreparedStatement ps = db.prepareStatement("SELECT balance FROM balances WHERE uuid=?")) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) value = rs.getDouble(1); }
        } catch (SQLException ex) { getLogger().warning(ex.getMessage()); }
        cache.put(p.getUniqueId(), value);
        return value;
    }

    private void setBalance(OfflinePlayer p, double amount) {
        cache.put(p.getUniqueId(), amount);
        String name = p.getName() == null ? p.getUniqueId().toString() : p.getName();
        try (PreparedStatement ps = db.prepareStatement(
                "INSERT INTO balances(uuid,name,balance) VALUES(?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,balance=excluded.balance")) {
            ps.setString(1, p.getUniqueId().toString()); ps.setString(2, name); ps.setDouble(3, amount); ps.executeUpdate();
        } catch (SQLException ex) { getLogger().warning(ex.getMessage()); }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("novar")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
            openMenu(player); return true;
        }
        if (cmd.equals("bal")) {
            if (args.length == 0 && sender instanceof Player player) {
                sender.sendMessage(prefix() + "&fYour balance: &a" + moneyText(balance(player)));
            } else if (args.length == 1) {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                sender.sendMessage(prefix() + "&f" + args[0] + "'s balance: &a" + moneyText(balance(target)));
            } else sender.sendMessage(color(prefix() + "&cUsage: /bal [player]"));
            return true;
        }
        if (cmd.equals("pay")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
            if (args.length != 2) { player.sendMessage(color(prefix() + "&cUsage: /pay <player> <amount>")); return true; }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null || target.equals(player)) { player.sendMessage(color(prefix() + "&cPlayer not found or invalid.")); return true; }
            double amount;
            try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException ex) { player.sendMessage(color(prefix() + "&cInvalid amount.")); return true; }
            if (!Double.isFinite(amount) || amount <= 0 || amount > 1_000_000_000_000d) { player.sendMessage(color(prefix() + "&cEnter a valid positive amount.")); return true; }
            double from = balance(player);
            if (from < amount) { player.sendMessage(color(prefix() + "&cYou don't have enough money.")); return true; }
            setBalance(player, from - amount);
            setBalance(target, balance(target) + amount);
            player.sendMessage(color(prefix() + "&aSent " + moneyText(amount) + " to " + target.getName() + "."));
            target.sendMessage(color(prefix() + "&aReceived " + moneyText(amount) + " from " + player.getName() + "."));
            return true;
        }
        if (cmd.equals("novaradmin")) {
            if (!sender.hasPermission("novarsmp.admin")) { sender.sendMessage(color(prefix() + "&cNo permission.")); return true; }
            if (args.length != 3) { sender.sendMessage(color(prefix() + "&cUsage: /novaradmin <set|add|take> <player> <amount>")); return true; }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            double amount;
            try { amount = Double.parseDouble(args[2]); } catch (NumberFormatException ex) { sender.sendMessage("Invalid amount."); return true; }
            if (!Double.isFinite(amount) || amount < 0) { sender.sendMessage("Enter a valid non-negative amount."); return true; }
            double old = balance(target);
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "set" -> setBalance(target, amount);
                case "add" -> setBalance(target, old + amount);
                case "take" -> setBalance(target, Math.max(0, old - amount));
                default -> { sender.sendMessage("Use set, add, or take."); return true; }
            }
            sender.sendMessage(color(prefix() + "&aUpdated " + args[1] + "'s balance."));
            return true;
        }
        return false;
    }

    private void openMenu(Player p) {
        String title = color(getConfig().getString("menu-title", "&8novarSMP"));
        Inventory inv = Bukkit.createInventory(null, 27, title);
        inv.setItem(11, item(Material.EMERALD, "&aYour Balance", "&7" + moneyText(balance(p))));
        inv.setItem(13, item(Material.GOLD_INGOT, "&6Economy", "&7Use &f/pay &7to send money", "&7Use &f/bal &7to check your balance"));
        inv.setItem(15, item(Material.BOOK, "&bComing Soon", "&7Shop, Auction House and RTP"));
        p.openInventory(inv);
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        meta.setLore(Arrays.stream(lore).map(this::color).toList());
        stack.setItemMeta(meta);
        return stack;
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (ChatColor.stripColor(e.getView().getTitle()).equalsIgnoreCase("novarSMP")) e.setCancelled(true);
    }
}
